<?php
// footer.php
?>
    <script src="scripts.js"></script>
</body>
</html>